# RPG Dashboard

Um dashboard gamificado estilo RPG com gráficos interativos, sistema de tarefas e medições de saúde.

## 📁 Estrutura do Projeto

```
rpg-dashboard-project/
├── html/
│   └── index.html          # Arquivo HTML principal
├── css/
│   └── styles.css          # Estilos CSS
├── js/
│   └── app.js              # Lógica JavaScript
├── docs/
│   ├── ESTRUTURA.md        # Documentação da estrutura
│   ├── COMPONENTES.md      # Detalhes dos componentes
│   └── CORES.md            # Paleta de cores
├── assets/                 # Pasta para imagens e recursos
└── README.md               # Este arquivo
```

## 🚀 Como Usar

1. Abra `html/index.html` em um navegador web
2. Interaja com as tarefas clicando nos checkboxes
3. Visualize os gráficos de atributos e evolução de peso
4. Monitore seu IMC no medidor

## 🎮 Componentes

### Header
- Avatar do jogador
- Nível e classe
- Exibição de moedas

### Barra de XP
- Progresso animado
- Indicador de ganho de XP
- Efeito shimmer

### Atributos
- Gráfico de radar com 5 atributos
- Visualização de força e fraquezas

### Evolução de Peso
- Gráfico de linha com histórico
- Acompanhamento de progresso

### IMC
- Medidor com 3 zonas (Normal, Sobrepeso, Obeso)
- Agulha indicadora de posição

### Missões Diárias
- 4 tarefas interativas
- Sistema de checkboxes
- Recompensa de XP

## 🎨 Design

- **Tema**: Medieval RPG
- **Paleta**: Beges, marrons e cores vibrantes
- **Estilo**: Parchment com bordas decorativas
- **Responsividade**: Desktop e mobile

## 📊 Tecnologias

- **HTML5**: Estrutura semântica
- **CSS3**: Estilos avançados com gradientes e animações
- **JavaScript Vanilla**: Lógica sem dependências
- **Chart.js**: Gráficos interativos

## 🔧 Customização

### Modificar Tarefas
Edite o array `tasks` em `js/app.js`:
```javascript
const tasks = [
    { id: 1, text: 'Sua tarefa', completed: false },
    // ...
];
```

### Alterar Cores
Modifique os códigos hex em `css/styles.css`:
```css
--primary-color: #d4af8a;
--secondary-color: #8b7355;
```

### Atualizar Dados dos Gráficos
Edite os valores em `js/app.js`:
```javascript
data: [85, 72, 80, 65, 78]  // Valores dos atributos
```

## 📱 Responsividade

- Desktop: Grid 2 colunas
- Tablet: Grid 1-2 colunas
- Mobile: Grid 1 coluna

## 🎯 Funcionalidades

✅ Gráfico de radar interativo
✅ Gráfico de linha com animações
✅ Medidor de IMC com zonas coloridas
✅ Sistema de tarefas com checkboxes
✅ Barra de XP animada
✅ Design responsivo
✅ Efeitos visuais e animações
✅ Sem dependências externas (exceto Chart.js)

## 📚 Documentação

- [ESTRUTURA.md](docs/ESTRUTURA.md) - Organização e componentes
- [COMPONENTES.md](docs/COMPONENTES.md) - Detalhes técnicos
- [CORES.md](docs/CORES.md) - Paleta e customização

## 🌐 Dependências Externas

- Chart.js 3.9.1 (via CDN)

## 📄 Licença

Livre para usar e modificar.

## 💡 Dicas

1. Use `html/index.html` como ponto de entrada
2. Customize cores em `css/styles.css`
3. Modifique dados em `js/app.js`
4. Consulte `docs/` para documentação detalhada

---

**Desenvolvido com ❤️ para gamificação de saúde e bem-estar**
