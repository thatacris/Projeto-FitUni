# Paleta de Cores - RPG Dashboard

## Cores Principais

### Marrom (Tema Medieval)
- **Marrom Escuro**: `#2c1810` - Fundo principal, texto escuro
- **Marrom Médio**: `#8b7355` - Bordas, linhas divisórias
- **Marrom Claro**: `#5d4e37` - Texto secundário
- **Bege**: `#d4af8a` - Fundo do container (parchment)
- **Bege Claro**: `#c9a876` - Gradiente do container
- **Bege Pálido**: `#e8d4b8` - Fundo dos cards
- **Bege Escuro**: `#d9c5a9` - Gradiente dos cards

### Texto
- **Primário**: `#f5e6d3` - Texto principal (claro)
- **Secundário**: `#5d4e37` - Texto secundário (escuro)
- **Terciário**: `#2c1810` - Texto em fundos claros

## Cores de Status

### XP e Progresso
- **Verde Claro**: `#2ecc71` - Barra de XP, tarefas completas
- **Verde Escuro**: `#27ae60` - Borda da barra, hover
- **Verde Muito Escuro**: `#1e8449` - Borda da barra

### Gráficos
- **Azul**: `#1e90ff` - Gráfico de radar
- **Azul com Transparência**: `rgba(30, 144, 255, 0.3)` - Preenchimento radar
- **Laranja**: `#ff9800` - Gráfico de linha (peso)
- **Laranja com Transparência**: `rgba(255, 152, 0, 0.2)` - Preenchimento linha

### IMC
- **Verde (Normal)**: `#2ecc71` - 0-25 kg/m²
- **Amarelo (Sobrepeso)**: `#f39c12` - 25-30 kg/m²
- **Vermelho (Obeso)**: `#e74c3c` - 30+ kg/m²

### Avatar
- **Vermelho Claro**: `#e74c3c` - Gradiente avatar
- **Vermelho Escuro**: `#c0392b` - Gradiente avatar

## Cores com Transparência

### Fundos Translúcidos
- `rgba(255, 255, 255, 0.3)` - Branco 30% (ouro display)
- `rgba(255, 255, 255, 0.5)` - Branco 50% (tarefas)
- `rgba(255, 255, 255, 0.8)` - Branco 80% (hover tarefas)
- `rgba(0, 0, 0, 0.1)` - Preto 10% (fundo IMC value)
- `rgba(0, 0, 0, 0.2)` - Preto 20% (inset shadow IMC gauge)
- `rgba(0, 0, 0, 0.3)` - Preto 30% (inset shadow cards)
- `rgba(0, 0, 0, 0.4)` - Preto 40% (box-shadow avatar)
- `rgba(0, 0, 0, 0.5)` - Preto 50% (box-shadow needle)
- `rgba(0, 0, 0, 0.8)` - Preto 80% (box-shadow container)

### Gradientes
- `rgba(255, 255, 255, 0.1)` - Inset shadow claro
- `rgba(255, 255, 255, 0.2)` - Inset shadow mais claro
- `rgba(139, 115, 85, 0.3)` - Grid dos gráficos

## Uso por Elemento

| Elemento | Cor Primária | Cor Secundária | Cor Terciária |
|----------|--------------|----------------|---------------|
| Body Background | #2c1810 | - | - |
| Container | #d4af8a | #c9a876 | - |
| Cards | #e8d4b8 | #d9c5a9 | - |
| Texto Principal | #f5e6d3 | - | - |
| Texto Escuro | #2c1810 | #5d4e37 | - |
| Bordas | #8b7355 | - | - |
| XP Bar | #2ecc71 | #27ae60 | #1e8449 |
| Radar | #1e90ff | rgba(30,144,255,0.3) | - |
| Peso | #ff9800 | rgba(255,152,0,0.2) | - |
| IMC Gauge | #2ecc71 | #f39c12 | #e74c3c |
| Avatar | #e74c3c | #c0392b | - |

## Gradientes Utilizados

### Container Principal
```css
background: linear-gradient(180deg, #d4af8a 0%, #c9a876 100%);
```

### Cards
```css
background: linear-gradient(135deg, #e8d4b8 0%, #d9c5a9 100%);
```

### Barra de XP
```css
background: linear-gradient(90deg, #2ecc71 0%, #27ae60 100%);
```

### Gráfico de Linha
```css
backgroundColor: 'rgba(255, 152, 0, 0.2)'
```

### IMC Gauge
```css
background: linear-gradient(90deg, 
    #2ecc71 0%, 
    #2ecc71 25%, 
    #f39c12 25%, 
    #f39c12 50%, 
    #e74c3c 50%, 
    #e74c3c 100%);
```

### Avatar
```css
background: linear-gradient(135deg, #e74c3c, #c0392b);
```

### Fundo Geral
```css
background: linear-gradient(135deg, #2c1810 0%, #1a0f08 100%);
```

## Acessibilidade de Cores

- Contraste de texto claro (#f5e6d3) sobre fundo escuro (#2c1810): ✓ Excelente
- Contraste de texto escuro (#2c1810) sobre fundo claro (#d4af8a): ✓ Excelente
- Contraste de verde (#2ecc71) sobre branco: ✓ Bom
- Contraste de laranja (#ff9800) sobre branco: ✓ Bom

## Dicas de Customização

1. **Tema Mais Escuro**: Reduzir luminosidade dos beges (ex: #c9a876 → #b89968)
2. **Tema Mais Claro**: Aumentar luminosidade dos beges (ex: #d4af8a → #e5c4a0)
3. **Cores Mais Vibrantes**: Aumentar saturação dos greens e oranges
4. **Cores Mais Suaves**: Reduzir saturação e aumentar transparência
5. **Tema Diferente**: Substituir #2c1810 por outra cor base e ajustar gradientes
