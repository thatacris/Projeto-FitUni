# Documentação de Componentes

## Header

### HTML
```html
<div class="header">
    <div class="player-info">
        <div class="player-avatar">🧔</div>
        <div class="player-details">
            <h1>Nível 12</h1>
            <p>Aventureiro</p>
        </div>
    </div>
    <div class="header-right">
        <div class="gold-display">
            <span class="gold-icon">💰</span>
            <span class="gold-amount">245</span>
        </div>
    </div>
</div>
```

### Classes CSS
- `.header` - Container principal
- `.player-info` - Informações do jogador
- `.player-avatar` - Avatar circular
- `.player-details` - Nome e classe
- `.header-right` - Lado direito do header
- `.gold-display` - Exibição de moedas

---

## Barra de XP

### HTML
```html
<div class="xp-section">
    <div class="xp-bar-container">
        <div class="xp-bar">
            <div class="xp-bar-fill"></div>
        </div>
        <span class="xp-text">680 / 1000 XP</span>
        <span class="xp-gain">+50 XP</span>
    </div>
</div>
```

### Animações
- `.xp-bar-fill::after` - Efeito shimmer (2s infinito)

### Customização
- Alterar `width: 68%` em `.xp-bar-fill` para mudar progresso
- Modificar cores em `background: linear-gradient()`

---

## Gráfico de Radar (Atributos)

### HTML
```html
<div class="card">
    <div class="card-title">Atributos</div>
    <div class="radar-container">
        <canvas id="radarChart"></canvas>
    </div>
</div>
```

### JavaScript
```javascript
new Chart(ctx, {
    type: 'radar',
    data: {
        labels: ['Disciplina', 'Foco', 'Saúde', 'Força', 'Resistência'],
        datasets: [{
            label: 'Atributos',
            data: [85, 72, 80, 65, 78],
            borderColor: '#1e90ff',
            backgroundColor: 'rgba(30, 144, 255, 0.3)',
            // ... mais configurações
        }]
    }
});
```

### Customização
- `data: [85, 72, 80, 65, 78]` - Valores dos atributos
- `labels` - Nomes dos atributos
- `borderColor` - Cor da borda
- `backgroundColor` - Cor de preenchimento

---

## Gráfico de Linha (Evolução de Peso)

### HTML
```html
<div class="card">
    <div class="card-title">Evolução de Peso</div>
    <div class="chart-container">
        <canvas id="lineChart"></canvas>
    </div>
</div>
```

### JavaScript
```javascript
new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['80 kg', '76 kg', '73 kg'],
        datasets: [{
            label: 'Peso',
            data: [80, 76, 73],
            borderColor: '#ff9800',
            backgroundColor: 'rgba(255, 152, 0, 0.2)',
            // ... mais configurações
        }]
    }
});
```

### Customização
- `data: [80, 76, 73]` - Valores de peso
- `labels` - Rótulos do eixo X
- `borderColor` - Cor da linha
- `backgroundColor` - Cor de preenchimento

---

## Medidor IMC

### HTML
```html
<div class="card">
    <div class="card-title">IMC</div>
    <div class="imc-container">
        <div class="imc-value">26.8</div>
        <div class="imc-gauge">
            <div class="imc-needle"></div>
        </div>
        <div class="imc-labels">
            <span>Normal</span>
            <span>Sobrepeso</span>
            <span>Obeso</span>
        </div>
    </div>
</div>
```

### Classes CSS
- `.imc-value` - Valor do IMC
- `.imc-gauge` - Barra de medição
- `.imc-needle` - Agulha indicadora
- `.imc-labels` - Rótulos das zonas

### Customização
- Alterar `left: 67%` em `.imc-needle` para mover a agulha
- Modificar gradiente em `.imc-gauge` para ajustar cores das zonas
- Atualizar valor em `.imc-value`

---

## Missões Diárias

### HTML
```html
<div class="tasks-section full-width">
    <div class="tasks-header">
        <div class="tasks-title">Missões Diárias</div>
        <div class="tasks-reward">+25 XP</div>
    </div>
    <div id="tasksList"></div>
</div>
```

### JavaScript
```javascript
const tasks = [
    { id: 1, text: 'Beber Água', completed: true },
    { id: 2, text: 'Treinar', completed: true },
    { id: 3, text: 'Ler 10 páginas', completed: false },
    { id: 4, text: 'Dormir 8 horas', completed: false }
];

function renderTasks() {
    const tasksList = document.getElementById('tasksList');
    tasksList.innerHTML = tasks.map(task => `
        <div class="task-item ${task.completed ? 'completed' : ''}" onclick="toggleTask(${task.id})">
            <div class="task-checkbox"></div>
            <span class="task-text">${task.text}</span>
        </div>
    `).join('');
}

function toggleTask(id) {
    const task = tasks.find(t => t.id === id);
    if (task) {
        task.completed = !task.completed;
        renderTasks();
    }
}
```

### Classes CSS
- `.task-item` - Container da tarefa
- `.task-checkbox` - Checkbox
- `.task-text` - Texto da tarefa
- `.completed` - Estado de conclusão

### Customização
- Adicionar tarefas ao array `tasks`
- Modificar cores em `.task-checkbox` quando `.completed`
- Alterar efeito hover em `.task-item:hover`

---

## Cards

### HTML
```html
<div class="card">
    <div class="card-title">Título</div>
    <!-- Conteúdo -->
</div>
```

### Classes CSS
- `.card` - Container do card
- `.card-title` - Título do card
- `.card::before` - Decoração superior

### Customização
- Alterar `background: linear-gradient()` para mudar cor
- Modificar `border-radius` para ajustar cantos
- Ajustar `padding` para espaçamento interno

---

## Cantos Decorativos

### HTML
```html
<div class="decorative-corner corner-tl"></div>
<div class="decorative-corner corner-tr"></div>
<div class="decorative-corner corner-bl"></div>
<div class="decorative-corner corner-br"></div>
```

### Classes CSS
- `.decorative-corner` - Estilo base
- `.corner-tl` - Canto superior esquerdo
- `.corner-tr` - Canto superior direito
- `.corner-bl` - Canto inferior esquerdo
- `.corner-br` - Canto inferior direito

### Customização
- Alterar `width` e `height` para mudar tamanho
- Modificar `border` para ajustar espessura
