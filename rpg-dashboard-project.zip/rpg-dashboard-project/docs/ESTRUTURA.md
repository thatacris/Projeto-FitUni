# Estrutura do Dashboard RPG

## 📁 Organização de Pastas

```
rpg-dashboard-project/
├── html/
│   └── index.html          # Arquivo HTML principal
├── css/
│   └── styles.css          # Todos os estilos CSS
├── js/
│   └── app.js              # Lógica JavaScript
├── docs/
│   ├── ESTRUTURA.md        # Este arquivo
│   ├── COMPONENTES.md      # Detalhes dos componentes
│   └── CORES.md            # Paleta de cores
└── assets/
    └── (imagens e recursos)
```

## 🎮 Componentes Principais

### 1. Header
- Avatar do jogador (100x100px)
- Nome do nível (Nível 12)
- Moeda/Ouro (245)

### 2. Barra de XP
- Barra de progresso animada (680/1000 XP)
- Indicador de ganho (+50 XP)
- Efeito shimmer na barra

### 3. Seção de Atributos
- Gráfico Radar (Chart.js)
- 5 atributos: Disciplina, Foco, Saúde, Força, Resistência
- Cores: Azul (#1e90ff)

### 4. Evolução de Peso
- Gráfico de Linha (Chart.js)
- Dados: 80kg → 76kg → 73kg
- Cores: Laranja (#ff9800)

### 5. IMC (Índice de Massa Corporal)
- Valor: 26.8
- Medidor com 3 zonas: Normal (verde), Sobrepeso (amarelo), Obeso (vermelho)
- Agulha indicadora

### 6. Missões Diárias
- 4 tarefas com checkboxes
- 2 completas, 2 incompletas
- Recompensa: +25 XP
- Interatividade: clique para marcar/desmarcar

## 🎨 Paleta de Cores

| Elemento | Cor | Código |
|----------|-----|--------|
| Fundo Principal | Marrom Escuro | #2c1810 |
| Fundo Container | Bege | #d4af8a |
| Texto Primário | Bege Claro | #f5e6d3 |
| Bordas | Marrom | #8b7355 |
| XP Bar | Verde | #2ecc71 |
| Radar | Azul | #1e90ff |
| Peso | Laranja | #ff9800 |
| IMC Normal | Verde | #2ecc71 |
| IMC Sobrepeso | Amarelo | #f39c12 |
| IMC Obeso | Vermelho | #e74c3c |

## 📊 Funcionalidades JavaScript

### renderTasks()
Renderiza dinamicamente a lista de tarefas com base no array `tasks`.

### toggleTask(id)
Alterna o status de conclusão de uma tarefa.

### initRadarChart()
Inicializa o gráfico de radar com 5 atributos usando Chart.js.

### initLineChart()
Inicializa o gráfico de linha para evolução de peso usando Chart.js.

## 📱 Responsividade

- **Desktop**: Grid 2 colunas
- **Mobile (<768px)**: Grid 1 coluna
- Header em coluna no mobile
- Ajustes de tamanho de fonte e padding

## ✨ Animações

1. **Shimmer na Barra XP**
   - Duração: 2s
   - Loop infinito
   - Efeito de brilho

2. **Hover nas Tarefas**
   - Translação: 5px
   - Transição suave: 0.3s

3. **Efeito de Profundidade**
   - Box-shadow múltiplas camadas
   - Inset shadows para efeito 3D

## 🔧 Como Usar

1. Abra `html/index.html` em um navegador
2. Clique nas tarefas para marcar/desmarcar
3. Os gráficos são renderizados automaticamente

## 📦 Dependências Externas

- Chart.js 3.9.1 (via CDN)
- Nenhuma biblioteca de framework (vanilla JavaScript)

## 🎯 Customização

### Dados Dinâmicos
- Modificar array `tasks` em `js/app.js`
- Alterar valores em `initRadarChart()` e `initLineChart()`
- Atualizar `imc-value` e posição do `imc-needle`

### Estilos
- Cores: Buscar por códigos hex em `css/styles.css`
- Tamanhos: Ajustar valores em `px`, `em`, ou `%`
- Fontes: Modificar `font-family` no body

### Comportamento
- Adicionar novos gráficos: Criar novo `<canvas>` e função `initChart()`
- Novos eventos: Adicionar listeners em elementos interativos
