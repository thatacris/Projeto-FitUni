const tasks = [
    { id: 1, text: 'Beber Água', completed: true },
    { id: 2, text: 'Treinar', completed: true },
    { id: 3, text: 'Ler 10 páginas', completed: false },
    { id: 4, text: 'Dormir 8 horas', completed: false }
];

function renderTasks() {
    const tasksList = document.getElementById('tasksList');
    tasksList.innerHTML = tasks.map(task => `
        <div class="task-item ${task.completed ? 'completed' : ''}" onclick="toggleTask(${task.id})">
            <div class="task-checkbox"></div>
            <span class="task-text">${task.text}</span>
        </div>
    `).join('');
}

function toggleTask(id) {
    const task = tasks.find(t => t.id === id);
    if (task) {
        task.completed = !task.completed;
        renderTasks();
    }
}

function initRadarChart() {
    const ctx = document.getElementById('radarChart').getContext('2d');
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Disciplina', 'Foco', 'Saúde', 'Força', 'Resistência'],
            datasets: [{
                label: 'Atributos',
                data: [85, 72, 80, 65, 78],
                borderColor: '#1e90ff',
                backgroundColor: 'rgba(30, 144, 255, 0.3)',
                borderWidth: 2,
                pointBackgroundColor: '#1e90ff',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        color: '#2c1810',
                        font: { size: 12 }
                    },
                    grid: {
                        color: 'rgba(139, 115, 85, 0.3)'
                    },
                    pointLabels: {
                        color: '#2c1810',
                        font: { size: 14, weight: 'bold' }
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

function initLineChart() {
    const ctx = document.getElementById('lineChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['80 kg', '76 kg', '73 kg'],
            datasets: [{
                label: 'Peso',
                data: [80, 76, 73],
                borderColor: '#ff9800',
                backgroundColor: 'rgba(255, 152, 0, 0.2)',
                borderWidth: 3,
                fill: true,
                pointBackgroundColor: '#ff9800',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 6,
                pointHoverRadius: 8,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            scales: {
                y: {
                    beginAtZero: false,
                    min: 70,
                    max: 85,
                    ticks: {
                        color: '#2c1810',
                        font: { size: 12 }
                    },
                    grid: {
                        color: 'rgba(139, 115, 85, 0.3)'
                    }
                },
                x: {
                    ticks: {
                        color: '#2c1810',
                        font: { size: 12 }
                    },
                    grid: {
                        display: false
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

renderTasks();
initRadarChart();
initLineChart();
